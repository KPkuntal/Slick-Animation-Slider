# slick slider layer sliding with animate css

A Pen created on CodePen.io. Original URL: [https://codepen.io/young/pen/MWYzOgO](https://codepen.io/young/pen/MWYzOgO).

